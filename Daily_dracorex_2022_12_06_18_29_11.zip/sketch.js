let currentSecond; 
let mm;
let milliFreeze;

function setup() {
  createCanvas(400, 400);
  textSize(80);
  currentSecond = second();
}

function draw() {
  background("aqua");
  
  circle(200,200,50)
  line(120,120,177,190)
  line(290,120,225,190)
  line(200,225,200,280)
  strokeWeight(12)
  
  circle(120,120,50)
  
  circle(200,300,50)
  
  
  circle(285,120,50)
  
  let d = day();
  let h = hour();
  let m = minute();
  let s = second();
  
  
  textSize(20);
  text(d,190,207);
  text(h,108,126);
  text(m,274,128)
  text(s,189,305);
  
  
  if (currentSecond != second()) {
    milliFreeze = millis();
    currentSecond = second();
  }  
  mm = millis() - milliFreeze;
  
  text(mm,400,400);

}